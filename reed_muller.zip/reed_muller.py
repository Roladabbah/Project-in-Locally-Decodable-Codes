from random import randint
from scipy.interpolate import lagrange
from numpy.linalg import inv


class Line2D:

    def __init__(self, a, b):
        """
        Defines the line a+b*t

        :param a: the point we want to compute its value - p(a)
        :param b: a random point in Fq^2
        """
        self.a = a
        self.b = b

    def eval(self, t: int):
        v = [t * self.b[0], t * self.b[1]]
        v = [v[0] + self.a[0], v[1] + self.a[1]]
        return v

    def __repr__(self):
        return "line = " + str(self.a) + "+ t * " + str(self.b)


class Monomial2D:

    def __init__(self, pow_x: int, pow_y: int):
        """
        Defines the monomial x^pow_x * y^pow_y

        :param pow_x: the power of the variable x
        :param pow_y: the power of the variable y
        """
        self._pow_x = pow_x
        self._pow_y = pow_y

    def eval(self, x: int, y: int):
        return pow(x, self._pow_x) * pow(y, self._pow_y)

    def get_powers(self):
        return [self._pow_x, self._pow_y]

    def __repr__(self):
        return 'x^' + str(self._pow_x) + 'y^' + str(self._pow_y)
        # return str(self._pow_x) + str(self._pow_y)


class Poly2D:

    def __init__(self, coeffs: list, q: int, d: int):
        """
        Defines bi-variate polynomial with the given coefficients. d is the polynomial degree and q is filed size

        :param coeffs: the coefficients
        :param q:  represents the final field Fq.
        :param d: the polynomial degree.
        """
        self._d = d
        self._q = q
        self._monomials = []  # length is k = d + 2 choose 2. According to the paper
        for i in range(0, d + 1):
            for j in range(0, d + 1):
                if i + j > d:
                    continue
                self._monomials.append(Monomial2D(pow_x=i, pow_y=j))

        if len(coeffs) != len(self._monomials):
            raise Exception("Invalid number of coefficients. It should be " + str(len(self._monomials)))

        for coeff in coeffs:
            if coeff < 0 or coeff > q-1:
                raise Exception("Coeffiecient out of range it should be between 0 and " + str(q-1))

        self._coeffs = coeffs

    def eval(self, x: int, y: int):
        """
        Evaluates the polynomial on the given x and y

        :param x: the x value
        :param y: the y value
        :return: the result of the evaluation P(x, y)
        """
        if x < 0 or x > self._q - 1:
            raise Exception("X value out of range it should be between 0 and " + str(self._q - 1))
        if y < 0 or y > self._q - 1:
            raise Exception("Y value out of range it should be between 0 and " + str(self._q - 1))

        value = 0

        for i in range(0, len(self._monomials)):
            value += self._coeffs[i] * self._monomials[i].eval(x=x, y=y)

        return value % self._q

    def __repr__(self):
        monomials_str_lst = []
        for i in range(0, len(self._monomials)):
            monomials_str_lst.append(str(self._coeffs[i]) + str(self._monomials[i]))

        return ' + '.join(monomials_str_lst)


def is_prime_number(number: int):
    if number > 1:
        for i in range(2, number):
            if (number % i) == 0:
                # print(number, "is not a prime number , please change the q value to a prime number !")
                return False
        else:
            # print(number, "is a prime number")
            return True


class ReedMullerBV:

    def __init__(self, q: int, d: int):
        """
        Defines a bi-variate reed muller code. This object can encode/decode the code.

        :param q: the final field Fq
        :param d: the code degree (polynomial degree)
        """
        self._q = q
        self._d = d

        if not is_prime_number(self._q):
            raise Exception("Invalid RM parameters , q should be prime number")
        if d >= q:
            raise Exception("Invalid RM parameters. d should be smaller that q")

    def encode(self, word: list):
        """
        Encodes the word by evaluating its polynomial of the number 0 - q^2-1. Then we get a code word of length q^2

        :param word: the input word that represents the polynom coefficients
        :return: the code word of length q^2
        """
        print("\n*** In encode Function ***")
        poly = Poly2D(word, q=self._q, d=self._d)
        code_word = []
        for x in range(0, self._q):
            for y in range(0, self._q):
                curr_val = poly.eval(x=x, y=y)
                code_word.append(curr_val)

        return code_word

    def point_val_in_relative(self, point, relative_code_word):
        """
        Returns the value of the point (x,y) in the relative_code_word

        :param point: the point we want to return its code value from relative code word
        :param relative_code_word: the word we want to return from it some information
        :return: the value of point in the word relative_code_word
        """
        code_word_index = 0
        for x in range(0, self._q):
            for y in range(0, self._q):
                if (x, y) == (point[0], point[1]):
                    # print("point: ", point)
                    return relative_code_word[code_word_index]
                code_word_index += 1

        return None

    def correct_point(self, x: int, y: int, b: [int, int], relative_code_word):
        """
        *assume that the point(x,y) need for correction
        Corrects the value P(a) given the point a=(x,y)

        :param x: the x coordinate of the point we want to correct
        :param y: the y coordinate of the point we want to correct
        :param b: random point in Fq^2
        :param relative_code_word: used to get other points vals
        :return:the corrected value of P(a)
        """

        print("  point a :", [x, y])
        print("  point b :", b)
        interpolation_points = []
        line = Line2D(a=[x, y], b=b)
        print(" ", line.__repr__())
        for t in range(1, self._d+2):  # we need d+1 points
            print("t: ", t)
            eval_point = line.eval(t)
            eval_point = [eval_point[0] % self._q, eval_point[1] % self._q]
            print("  point of (a + b * t) when t = ", t, " :", eval_point)
            q_t = self.point_val_in_relative(eval_point, relative_code_word)
            print("  - the evaluation of q on t : q("+str(t)+") :", q_t)
            print("  - the point (t , q(t)) when t = "+str(t)+" => "+str((t, q_t)))
            interpolation_points.append((t, q_t))

        print("\nInterpolations points :", interpolation_points)
        arrx = [i[0] for i in interpolation_points]
        arry = [i[1] for i in interpolation_points]
        print("  the x coordinates of the points :", arrx)
        print("  the y coordinates of the points :", arry)
        poly = lagrange(arrx, arry)
        print("\nPolynomial interpolation , gives us an approximation of the polynomial P(X,Y) :"+str(poly))
        poly_0 = poly(0) % self._q
        print(" * q(0) = P(a) : ", poly_0)

        return poly_0

    def get_random_point(self, x: int, y: int):

        rndx = randint(0, self._q - 1)
        rndy = randint(0, self._q - 1)
        while rndx == 0 and rndy == 0:
            rndx = randint(0, self._q - 1)
            rndy = randint(0, self._q - 1)
        b = [rndx, rndy]
        return b

    def correct(self, relative_code_word, point):
        """
        assume that relative_code_word is an array

        :param relative_code_word: a 'noisy' code word
        :return: corrected codeword
        """
        print("\n*** In correct Function ***")
        x = point[0]
        y = point[1]
        b = self.get_random_point(x, y)
        corrected_point = self.correct_point(x, y, b, relative_code_word)
        # print("\n==> corrected point : ", corrected_point)

        corrected_code_word = []
        index = 0
        for x1 in range(0, self._q):
            for y1 in range(0, self._q):
                if x1 == x and y1 == y:
                    corrected_code_word.append(corrected_point)
                else:
                    corrected_code_word.append(relative_code_word[index])
                index += 1

        return corrected_code_word

    def generate_monomials(self, q: int, d: int):

        self._d = d
        self._q = q
        monomials = []  # length is k = d + 2 choose 2. According to the paper
        for i in range(0, d + 1):
            for j in range(0, d + 1):
                if i + j > d:
                    continue
                monomials.append(Monomial2D(pow_x=i, pow_y=j))
        return monomials

    def get_codeword_according_to_indexes(self, indexes_lst, corrected_word):
        """

        returns the encoding of the given indexes x and y in the corrected_word.
        :param indexes_lst:
        :param corrected_word:
        :return:
        """
        x_y_c = []
        for xy in indexes_lst:
            i = 0
            # print(xy)
            for x in range(self._q):
                for y in range(self._q):
                    if [x, y] == xy:
                        # print("relative[i] : ", corrected_word[i])
                        x_y_c.append(corrected_word[i])
                        i += 1
                    else:
                        i += 1
        return x_y_c

    def monomials_eval_on_powlst(self, pow_list, monomials, ):
        values = []
        for powij in pow_list:
            vec = []
            for monom in monomials:
                vec.append(monom.eval(powij[0], powij[1]))
            values.append(vec)
        return values

    def pows_of_monomials(self, monomials):
        pow_list = []
        for monom in monomials:
            indexes = monom.get_powers()
            pow_list.append(indexes)
        return pow_list

    def decode(self, relative_code_word):
        """
         Decodes a code word into the original word. Throws an exception in case we cant decode the word

        :param relative_code_word: a code word of size q^2 that may be correct and may not
        :return: a coefficients list of the polynomial p that gives the relative_code_word`

        """

        # corrected_word = self.correct(relative_code_word, (0, 1))
        print("\n*** In decode Function ***\n")
        monomials = self.generate_monomials(q=self._q, d=self._d)
        print("  generate monomials ->  monomials :", monomials)
        powers_list = self.pows_of_monomials(monomials)  # returns the pow of x,y of each monomial in a tuple
        print("  indexes list (x's and y's) :", powers_list)
        values = self.monomials_eval_on_powlst(powers_list, monomials)
        print("  values of monomials on indexes lists :\n", values)
        x_y_c = self.get_codeword_according_to_indexes(powers_list, corrected_word)
        print("  code word of (x,y)'s : ", x_y_c)
        inv_values = inv(values)  # inverse matrix od values
        print("  inverse matrix : \n", inv_values)
        coeffetions_input = inv_values.dot(x_y_c) % self._q
        print("  coeffections  : ", coeffetions_input,"\n")
        return coeffetions_input


if __name__ == '__main__':

    # Example1:
    rm = ReedMullerBV(q=3, d=1)
    code_word = rm.encode(word=[1, 2, 2])
    print("code_word : ", code_word)

    relative_code_word = code_word
    relative_code_word[1] = (code_word[1]+1) % rm._q
    print("relative_code_word : ", relative_code_word)

    corrected_word = rm.correct(relative_code_word, (0, 1))
    decoded_r = rm.decode(corrected_word)
    print("decoded word : ", decoded_r)

    # Example2:
    # rm = ReedMullerBV(q=5, d=2)
    # code_word = rm.encode(word=[0, 1, 0, 0, 0, 1])
    # print("code_word : ", code_word)
    #
    # relative_code_word = code_word
    # relative_code_word[1] = (code_word[1]+1) % rm._q
    # print("relative_code_word : ", relative_code_word)
    #
    # corrected_word = rm.correct(relative_code_word, (0, 1))
    # decoded_r = rm.decode(corrected_word)
    # print("decoded word : ", decoded_r)
    #









